<script setup>
import { ref, reactive } from "vue"; 
 
var query = ref("550"); 
var api_key = "ac4eda4c3c1feecd8710a23ced1f9a54";
//we are filling in some data to avoid errors in our browser 
const state = reactive({ 
  movie: { 
    title: {}, 
    genres: {}, 
    poster_path: {}, 
    tagline: {}, 
    overview: {},
    release_date: {},
  }
}); 
 
var requestOptions = { 
  method: "GET", 
  redirect: "follow", 
}; 
 
fetchMov() 
function fetchMov() { 
  if (query.value.charAt(0) !== '0' &&
  query.value.charAt(0) !== '1' &&
  query.value.charAt(0) !== '2' &&
  query.value.charAt(0) !== '3' &&
  query.value.charAt(0) !== '4' &&
  query.value.charAt(0) !== '5' &&
  query.value.charAt(0) !== '6' &&
  query.value.charAt(0) !== '7' &&
  query.value.charAt(0) !== '8' &&
  query.value.charAt(0) !== '9') {
    console.log("string detected");
    if (query.value != null && query.value != "" && query.value != undefined){
    fetch(`https://api.themoviedb.org/3/search/movie?api_key=${api_key}&query=${query.value}`, 
  requestOptions) 
      .then((response) => { 
        return response.json(); 
      }) 
      .then(setResults2) 
      .catch((error) => console.log("error", error)); 
    query.value = ""; 
    }
  } else {
    console.log("number detected");
  if (query.value != null && query.value != "" && query.value != undefined){
  fetch(`https://api.themoviedb.org/3/movie/${query.value}?api_key=${api_key}`, 
requestOptions) 
    .then((response) => { 
      return response.json(); 
    }) 
    .then(setResults) 
    .catch((error) => console.log("error", error)); 
  query.value = ""; 
  }
}
}

function setResults(results) { 
  state.movie = results; 
  state.movie.poster_path = "https://image.tmdb.org/t/p/original/" + state.movie.poster_path;
} 

function setResults2(results) { 
  state.movie = results.results[0]; 
  state.movie.poster_path = "https://image.tmdb.org/t/p/original/" + state.movie.poster_path;
} 

</script>

<template>
  <div class="bg">
    <div class="navbar">
        <a>Most Popular Movie</a>&emsp;
        <a>Top Rated Movie</a>&emsp;
        <a>Latest Movie</a>&emsp;
        <a>Upcoming Movie</a>
      </div>
    <h1 class="text">Welcome to the MoviesDB API!</h1>
    <h2 class="text">Find information on your favorite movie here!</h2>
    <div class="container">
      
    <h1 class="name">{{state.movie.title}}</h1>
    <h2 class="name">{{state.movie.tagline}}</h2>
    <img class="poster" :src="state.movie.poster_path"/>
    <p class="p">{{state.movie.release_date}}</p>
    <p class="p">{{state.movie.overview}}</p>

<h1></h1>
    <input 
        v-model="query" 
        placeholder="Enter Movie ID or Name and hit Enter!" 
        @keyup.enter="fetchMov" 
      /> 
      
      </div>
      <footer>
        <p>This website was developed by Eric Yang</p>
        <p>Email: <a href="eyang12@uncc.edu">eyang12@uncc.edu</a></p>
        <p>Phone Number: XXX-XXX-XXXX</p>
      </footer>
  </div>
</template>

<style>
body, html {
  height: 100%;
  align-content: center;
  text-align: center;
  color: white;
}

footer{
  position: absolute;
  background-color: rgb(238, 214, 149);
  font-size: 12px;
  color: rgb(0, 0, 0);
  bottom: -500px;
  width:99%;
  height: auto;
}


h1, h2{
  text-shadow: 2px 0 0 black, -2px 0 0 black, 0 2px 0 black, 0 -2px 0 black, 1px 1px black, -1px -1px 0 black, 1px -1px 0 black, -1px 1px 0 black;
}

input {
  width: 250px;
  height: 32px;
}

.p{
  color: black;
  max-width: 800px;
  text-align: center;
  margin-right: auto;
  margin-left: auto;
  font-size: 20px;
  font-stretch: 110%;
}

.bg{
  background-image: url(https://wallpaperaccess.com/full/3658597.jpg);
  height:1200px;
}

.container{
  background-color: rgba(184, 167, 109, 0);
  background-image: url(https://wallpaperaccess.com/full/3872578.png);
  background-size: 100% 100%;
  align-content: center;
  padding-top: 80px;
  width: 75%;
  height: 120%;
  margin: auto;
  text-align: center;
  position: absolute;
  left: 12%;
  top: 20%;
}

.poster {
  height: 400px;
  width: 250px;
  display:inline-block;
  border: 1px solid black;
}

.text{
  font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
  color: white;
  padding: 5px;
}

.name{
  text-shadow: none;
  color: black;
}

.navbar {
  background-color: black;
  overflow: hidden;
  color: white;
  padding: 10px solid black;
  padding-top: 10px;
  margin: auto;
  height: 30px;
  
}

.navbar a:hover {
  color: rgb(74, 74, 221);
  font-size: 115%;
}

</style>